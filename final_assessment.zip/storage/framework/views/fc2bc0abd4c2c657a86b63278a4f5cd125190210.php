  <!-- Latest jQuery form server -->
  <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="<?php echo e(asset('Frontend')); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('Frontend')); ?>/js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="<?php echo e(asset('Frontend')); ?>/js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="<?php echo e(asset('Frontend')); ?>/js/main.js"></script>
    
    <!-- Slider -->
    <script type="text/javascript" src="<?php echo e(asset('Frontend')); ?>/js/bxslider.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('Frontend')); ?>/js/script.slider.js"></script><?php /**PATH D:\xampp\htdocs\final_assessment\resources\views/frontend/includes/scripts.blade.php ENDPATH**/ ?>