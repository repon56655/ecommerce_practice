                       
<?php $__env->startSection('contents'); ?>                
    <div class="col-md-6 offset-md-3">

        <h4 class="mt-3">Update Information</h4>

        <form action="<?php echo e(route('backend.updateproduct',$product->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="text" class="form-control mt-3" value="<?php echo e($product->name); ?>" name="name" placeholder="Enter Product Name">

            <input type="text" class="form-control mt-3" value="<?php echo e($product->category_name); ?>" name="category_name" placeholder="Enter Category Name">

            <input type="text" class="form-control mt-3" value="<?php echo e($product->brand_name); ?>" name="brand_name" placeholder="Enter Brand Name">

            <textarea type="text" class="form-control mt-3" name="description" placeholder="Enter Product Description"><?php echo e($product->description); ?></textarea>

            <input type="file" value="<?php echo e($product->image); ?>" class="form-control mt-3" name="image" required>

            <input type="text" class="form-control mt-3" value="<?php echo e($product->price); ?>" name="price">

            <select name="status" class="form-control mt-3">
                <option value="0">-----Select Status-----</option>
                <option value="1" <?php if($product->status = 1): ?>selected <?php endif; ?>>Active</option>
                <option value="2" <?php if($product->status = 2): ?>selected <?php endif; ?>>Inactive</option>
            </select>

            <button class="btn-add btn btn-success form-control mt-3">Update Product</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final_assessment\resources\views/backend/pages/edit.blade.php ENDPATH**/ ?>