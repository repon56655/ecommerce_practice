                       
<?php $__env->startSection('contents'); ?>                
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        DataTable Example
    </div>
        <div class="col-md-6 offset-md-3">
            <a href="<?php echo e(route('backend.addproduct')); ?>" class="btn btn-success"><i class="fa-sharp fa-solid fa-plus"></i>Add Product</a>
        </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>#Sl</th>
                    <th>Name</th>
                    <th>Category Name</th>
                    <th>Brand Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>#Sl</th>
                    <th>Name</th>
                    <th>Category Name</th>
                    <th>Brand Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
            <tbody>
            <?php $sl=1; ?>
                
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sl); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->category_name); ?></td>
                    <td><?php echo e($product->brand_name); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td>
                        <img height="50" width="75" src="<?php echo e(asset('backend/image/'.$product->image)); ?>" alt="product image">
                    </td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('backend.editproduct',$product->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a><a href="<?php echo e(route('backend.deleteproduct',$product->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php $sl++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\final_assessment\resources\views/backend/pages/manage.blade.php ENDPATH**/ ?>